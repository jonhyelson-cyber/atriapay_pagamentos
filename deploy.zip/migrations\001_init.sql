PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS merchants (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  document TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bank_accounts (
  id TEXT PRIMARY KEY,
  merchant_id TEXT NOT NULL,
  bank_code TEXT,
  agency TEXT,
  account TEXT,
  account_type TEXT,
  pix_key TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (merchant_id) REFERENCES merchants(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS charges (
  id TEXT PRIMARY KEY,
  merchant_id TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  currency TEXT NOT NULL,
  method TEXT NOT NULL,
  provider TEXT NOT NULL,
  provider_ref TEXT,
  status TEXT NOT NULL,
  markup_cents INTEGER NOT NULL,
  description TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (merchant_id) REFERENCES merchants(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_charges_provider_ref ON charges(provider, provider_ref);
CREATE TABLE IF NOT EXISTS charge_events (
  id TEXT PRIMARY KEY,
  charge_id TEXT NOT NULL,
  type TEXT NOT NULL,
  payload TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (charge_id) REFERENCES charges(id) ON DELETE CASCADE
);

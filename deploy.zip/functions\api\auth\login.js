import { jwtSign, hashPassword } from './_utils.js';

export async function onRequest(context) {
  const { request, env } = context;

  // Habilitar CORS
  if (request.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'access-control-allow-origin': '*',
        'access-control-allow-methods': 'POST, OPTIONS',
        'access-control-allow-headers': 'Content-Type'
      }
    });
  }

  if (request.method !== 'POST') return new Response(null, { status: 405 });

  const db = env.gateway_atria || env.DB;
  const secret = env.SESSION_SECRET || 'dev-secret';

  if (!db) {
    return new Response(JSON.stringify({ error: 'db_unavailable' }), { status: 503, headers: { 'content-type': 'application/json' } });
  }

  const body = await request.json();
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');

  if (!email || !password) {
    return new Response(JSON.stringify({ error: 'invalid_payload' }), { status: 400, headers: { 'content-type': 'application/json' } });
  }

  const row = await db.prepare(`
    SELECT u.id as user_id, u.password_hash, u.password_salt, m.merchant_id 
    FROM users u 
    LEFT JOIN user_merchants m ON m.user_id = u.id 
    WHERE u.email = ?1
  `).bind(email).first();

  if (!row) {
    return new Response(JSON.stringify({ error: 'invalid_credentials' }), { status: 401, headers: { 'content-type': 'application/json' } });
  }

  const got = await hashPassword(password, row.password_salt);
  if (got !== row.password_hash) {
    return new Response(JSON.stringify({ error: 'invalid_credentials' }), { status: 401, headers: { 'content-type': 'application/json' } });
  }

  const token = await jwtSign({ sub: row.user_id, email, merchant_id: row.merchant_id || null }, secret, 60 * 60 * 24 * 7);
  
  const headers = new Headers({
    'content-type': 'application/json',
    'set-cookie': `session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${60 * 60 * 24 * 7}`,
    'access-control-allow-origin': '*'
  });

  return new Response(JSON.stringify({ user_id: row.user_id, merchant_id: row.merchant_id || null }), { status: 200, headers });
}

import { jwtSign, hashPassword, randomId } from './_utils.js';

export async function onRequest(context) {
  const { request, env } = context;

  // Habilitar CORS
  if (request.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'access-control-allow-origin': '*',
        'access-control-allow-methods': 'POST, OPTIONS',
        'access-control-allow-headers': 'Content-Type'
      }
    });
  }

  if (request.method !== 'POST') return new Response(null, { status: 405 });

  const db = env.gateway_atria || env.DB;
  const secret = env.SESSION_SECRET || 'dev-secret';

  const body = await request.json();
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');
  const name = String(body.name || 'Minha Loja').trim() || 'Minha Loja';
  const document = body.document ? String(body.document) : null;

  if (!email || !password) {
    return new Response(JSON.stringify({ error: 'invalid_payload' }), { status: 400, headers: { 'content-type': 'application/json' } });
  }

  if (!db) {
    return new Response(JSON.stringify({ error: 'db_unavailable' }), { status: 503, headers: { 'content-type': 'application/json' } });
  }

  const now = new Date().toISOString();
  const userId = randomId();
  const salt = randomId();
  const pass = await hashPassword(password, salt);

  try {
    await db.prepare('INSERT INTO users (id,email,password_hash,password_salt,created_at) VALUES (?1,?2,?3,?4,?5)')
      .bind(userId, email, pass, salt, now).run();
  } catch (e) {
    return new Response(JSON.stringify({ error: 'email_in_use' }), { status: 409, headers: { 'content-type': 'application/json' } });
  }

  const merchantId = randomId();
  await db.prepare('INSERT INTO merchants (id,name,email,document,created_at) VALUES (?1,?2,?3,?4,?5)')
    .bind(merchantId, name, email, document, now).run();
  
  await db.prepare('INSERT INTO user_merchants (user_id,merchant_id) VALUES (?1,?2)')
    .bind(userId, merchantId).run();

  const token = await jwtSign({ sub: userId, email, merchant_id: merchantId }, secret, 60 * 60 * 24 * 7);
  
  const headers = new Headers({
    'content-type': 'application/json',
    'set-cookie': `session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${60 * 60 * 24 * 7}`,
    'access-control-allow-origin': '*'
  });

  return new Response(JSON.stringify({ user_id: userId, merchant_id: merchantId }), { status: 201, headers });
}

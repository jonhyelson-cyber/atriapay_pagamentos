export async function onRequest(context) {
  const { request, env } = context;
  if (request.method !== 'POST') {
    return new Response(null, { status: 405 });
  }
  const db = env.gateway_atria || env.DB;
  const data = await request.json();
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const name = String(data.name || '').trim();
  const email = String(data.email || '').trim().toLowerCase();
  const document = String(data.document || '').trim();
  if (!name || !email) {
    return new Response(JSON.stringify({ error: 'invalid_payload' }), { status: 400, headers: { 'content-type': 'application/json' } });
  }
  if (db) {
    await db.prepare('INSERT INTO merchants (id,name,email,document,created_at) VALUES (?1,?2,?3,?4,?5)')
      .bind(id, name, email, document || null, now).run();
    if (data.bank && typeof data.bank === 'object') {
      const bankId = crypto.randomUUID();
      const bank = data.bank;
      await db.prepare('INSERT INTO bank_accounts (id,merchant_id,bank_code,agency,account,account_type,pix_key,created_at) VALUES (?1,?2,?3,?4,?5,?6,?7,?8)')
        .bind(
          bankId,
          id,
          String(bank.bank_code || ''),
          String(bank.agency || ''),
          String(bank.account || ''),
          String(bank.type || ''),
          bank.pix_key ? String(bank.pix_key) : null,
          now
        ).run();
    }
  }
  return new Response(JSON.stringify({ id }), { status: 201, headers: { 'content-type': 'application/json' } });
}

export async function onRequest(context) {
  const { request, env } = context;
  if (request.method !== 'POST') {
    return new Response(null, { status: 405 });
  }
  const db = env.gateway_atria || env.DB;
  const now = new Date().toISOString();
  const payload = await request.json();
  const type = String(payload.type || 'event');
  const data = payload.data || {};
  const id = crypto.randomUUID();
  const providerRef = data.id ? String(data.id) : null;
  let chargeId = null;
  if (providerRef && db) {
    const row = await db.prepare('SELECT id FROM charges WHERE provider=?1 AND provider_ref=?2').bind('mercadopago', providerRef).first();
    if (row && row.id) chargeId = row.id;
  }
  if (chargeId && db) {
    let status = null;
    if (type.includes('payment')) {
      if (payload.action === 'payment.created') status = 'pending';
      if (payload.action === 'payment.updated' && payload.data && payload.data.status === 'approved') status = 'paid';
      if (payload.action === 'payment.updated' && payload.data && payload.data.status === 'rejected') status = 'failed';
    }
    if (status) {
      await db.prepare('UPDATE charges SET status=?1, updated_at=?2 WHERE id=?3').bind(status, now, chargeId).run();
    }
    await db.prepare('INSERT INTO charge_events (id,charge_id,type,payload,created_at) VALUES (?1,?2,?3,?4,?5)')
      .bind(id, chargeId, type, JSON.stringify(payload), now).run();
  }
  return new Response(null, { status: 200 });
}

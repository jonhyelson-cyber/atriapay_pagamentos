export async function onRequest(context) {
  const headers = new Headers({
    'content-type': 'application/json',
    'set-cookie': `session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`
  });
  return new Response(JSON.stringify({ ok: true }), { status: 200, headers });
}

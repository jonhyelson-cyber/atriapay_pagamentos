async function createMPPreference(env, charge) {
  if (!env.MERCADOPAGO_TOKEN) return { checkout_url: `https://example.com/pagar/${charge.id}`, provider_ref: null };
  const body = {
    items: [{ title: charge.description || 'Pagamento', quantity: 1, unit_price: charge.amount_cents / 100 }],
    currency_id: charge.currency || 'BRL',
    marketplace_fee: charge.markup_cents / 100,
    back_urls: { success: 'https://example.com/sucesso', pending: 'https://example.com/pendente', failure: 'https://example.com/falha' },
    auto_return: 'approved'
  };
  const res = await fetch('https://api.mercadopago.com/checkout/preferences', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${env.MERCADOPAGO_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!res.ok) return { checkout_url: `https://example.com/pagar/${charge.id}`, provider_ref: null };
  const json = await res.json();
  return { checkout_url: json.init_point || json.sandbox_init_point || `https://example.com/pagar/${charge.id}`, provider_ref: json.id || null };
}

async function createAFI(env, charge) {
  return { checkout_url: `https://example.com/pagar/${charge.id}`, provider_ref: null };
}

async function createMPPayment(env, payload) {
  if (!env.MERCADOPAGO_TOKEN) {
    return { provider_ref: null, checkout: null };
  }
  const res = await fetch('https://api.mercadopago.com/v1/payments', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${env.MERCADOPAGO_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const txt = await res.text();
    return { provider_ref: null, checkout: null, error: txt };
  }
  const json = await res.json();
  let checkout = null;
  if (json.point_of_interaction && json.point_of_interaction.transaction_data) {
    const t = json.point_of_interaction.transaction_data;
    checkout = {
      type: payload.payment_method_id,
      qr_code: t.qr_code || null,
      qr_code_base64: t.qr_code_base64 || null,
      ticket_url: t.ticket_url || null
    };
  }
  return { provider_ref: String(json.id), checkout };
}

function computeMarkupCents(method, amountCents) {
  if (method === 'pix') return Math.round(amountCents * 0.0189);
  if (method === 'cartao') return Math.round(amountCents * 0.0699);
  if (method === 'boleto') return 299;
  return 0;
}

export async function onRequest(context) {
  const { request, env } = context;
  if (request.method !== 'POST') {
    return new Response(null, { status: 405 });
  }
  const db = env.gateway_atria || env.DB;
  const now = new Date().toISOString();
  const body = await request.json();
  const id = crypto.randomUUID();
  const merchantId = String(body.merchant_id || '').trim();
  const amount = Number(body.amount || 0);
  const currency = String(body.currency || 'BRL').toUpperCase();
  const method = String(body.method || '').toLowerCase();
  const provider = String(body.provider || 'mercadopago').toLowerCase();
  const description = body.description ? String(body.description) : null;
  const checkoutMode = String(body.checkout_mode || 'direct').toLowerCase();
  const payer = body.payer && typeof body.payer === 'object' ? body.payer : {};
  const cardToken = body.card_token ? String(body.card_token) : null;
  if (!merchantId || !amount || amount <= 0) {
    return new Response(JSON.stringify({ error: 'invalid_payload' }), { status: 400, headers: { 'content-type': 'application/json' } });
  }
  const amountCents = Math.round(amount * 100);
  const markupCents = computeMarkupCents(method, amountCents);
  if (db) {
    await db.prepare('INSERT INTO charges (id,merchant_id,amount_cents,currency,method,provider,status,markup_cents,created_at,updated_at,description) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11)')
      .bind(id, merchantId, amountCents, currency, method, provider, 'pending', markupCents, now, now, description).run();
  }
  let checkoutUrl = null;
  let providerRef = null;
  let checkoutData = null;
  if (provider === 'mercadopago') {
    if (checkoutMode === 'direct') {
      if (method === 'pix') {
        const payload = {
          transaction_amount: amountCents / 100,
          description: description || 'Pagamento',
          payment_method_id: 'pix',
          payer: {
            email: payer.email || undefined,
            first_name: payer.first_name || undefined,
            last_name: payer.last_name || undefined
          },
          application_fee: markupCents / 100
        };
        const r = await createMPPayment(env, payload);
        providerRef = r.provider_ref;
        checkoutData = r.checkout;
      } else if (method === 'boleto') {
        const payload = {
          transaction_amount: amountCents / 100,
          description: description || 'Pagamento',
          payment_method_id: 'bolbradesco',
          payer: {
            email: payer.email || undefined,
            first_name: payer.first_name || undefined,
            last_name: payer.last_name || undefined,
            identification: payer.identification || undefined,
            address: payer.address || undefined
          },
          application_fee: markupCents / 100
        };
        const r = await createMPPayment(env, payload);
        providerRef = r.provider_ref;
        checkoutData = r.checkout;
      } else if (method === 'cartao') {
        const payload = {
          transaction_amount: amountCents / 100,
          description: description || 'Pagamento',
          payment_method_id: 'visa',
          token: cardToken || undefined,
          payer: {
            email: payer.email || undefined
          },
          application_fee: markupCents / 100
        };
        const r = await createMPPayment(env, payload);
        providerRef = r.provider_ref;
        checkoutData = r.checkout;
      } else {
        const r = await createMPPreference(env, { id, amount_cents: amountCents, currency, markup_cents: markupCents, description });
        checkoutUrl = r.checkout_url;
        providerRef = r.provider_ref;
      }
    } else {
      const r = await createMPPreference(env, { id, amount_cents: amountCents, currency, markup_cents: markupCents, description });
      checkoutUrl = r.checkout_url;
      providerRef = r.provider_ref;
    }
  } else if (provider === 'afibank') {
    const r = await createAFI(env, { id, amount_cents: amountCents, currency, markup_cents: markupCents, description });
    checkoutUrl = r.checkout_url;
    providerRef = r.provider_ref;
  }
  if (!env.MERCADOPAGO_TOKEN && !checkoutUrl && !checkoutData) {
    if (method === 'pix') {
      checkoutData = {
        type: 'pix',
        qr_code: '00020126360014BR.GOV.BCB.PIX0114+55999999999952040000530398654061.235802BR5908DEMO PIX6009SAO PAULO62070503***6304ABCD',
        qr_code_base64: null
      };
    } else if (method === 'boleto') {
      checkoutData = {
        type: 'boleto',
        ticket_url: 'https://example.com/boleto-demo'
      };
    } else {
      checkoutUrl = `https://example.com/pagar/${id}`;
    }
  }
  if (providerRef && db) {
    await db.prepare('UPDATE charges SET provider_ref=?1, updated_at=?2 WHERE id=?3').bind(providerRef, now, id).run();
  }
  return new Response(JSON.stringify({ id, checkout_url: checkoutUrl, checkout: checkoutData }), { status: 201, headers: { 'content-type': 'application/json' } });
}

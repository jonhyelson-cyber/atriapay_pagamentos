import { jwtVerify } from './_utils.js';

function getCookie(req, name) {
  const h = req.headers.get('Cookie') || '';
  const m = h.match(new RegExp('(?:^|;)\\s*' + name + '=([^;]+)'));
  return m ? decodeURIComponent(m[1]) : null;
}

export async function onRequest(context) {
  const { request, env } = context;
  const secret = env.SESSION_SECRET || 'dev-secret';

  const token = getCookie(request, 'session');
  
  if (!token) {
    return new Response(JSON.stringify({ user: null }), { 
      status: 200, 
      headers: { 'content-type': 'application/json', 'access-control-allow-origin': '*' } 
    });
  }

  const payload = await jwtVerify(token, secret);
  
  if (!payload) {
    return new Response(JSON.stringify({ user: null }), { 
      status: 200, 
      headers: { 'content-type': 'application/json', 'access-control-allow-origin': '*' } 
    });
  }

  return new Response(JSON.stringify({ 
    user: { id: payload.sub, email: payload.email, merchant_id: payload.merchant_id || null } 
  }), { 
    status: 200, 
    headers: { 'content-type': 'application/json', 'access-control-allow-origin': '*' } 
  });
}

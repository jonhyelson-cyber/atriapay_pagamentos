export async function onRequest(context) {
  const { request, env } = context;
  if (request.method !== 'POST') {
    return new Response(null, { status: 405 });
  }
  const db = env.gateway_atria || env.DB;
  const now = new Date().toISOString();
  const payload = await request.json();
  const type = String(payload.type || 'event');
  const id = crypto.randomUUID();
  const providerRef = payload.reference ? String(payload.reference) : null;
  let chargeId = null;
  if (providerRef && db) {
    const row = await db.prepare('SELECT id FROM charges WHERE provider=?1 AND provider_ref=?2').bind('afibank', providerRef).first();
    if (row && row.id) chargeId = row.id;
  }
  if (chargeId && db) {
    let status = null;
    if (payload.status === 'paid') status = 'paid';
    if (payload.status === 'failed') status = 'failed';
    if (payload.status === 'pending') status = 'pending';
    if (status) {
      await db.prepare('UPDATE charges SET status=?1, updated_at=?2 WHERE id=?3').bind(status, now, chargeId).run();
    }
    await db.prepare('INSERT INTO charge_events (id,charge_id,type,payload,created_at) VALUES (?1,?2,?3,?4,?5)')
      .bind(id, chargeId, type, JSON.stringify(payload), now).run();
  }
  return new Response(null, { status: 200 });
}

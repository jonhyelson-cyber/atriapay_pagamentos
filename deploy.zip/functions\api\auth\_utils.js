export function b64urlEncode(buf) {
  let binary = '';
  const bytes = new Uint8Array(buf);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  let base = btoa(binary);
  return base.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function b64urlEncodeStr(str) {
  return b64urlEncode(new TextEncoder().encode(str));
}

export function b64urlDecodeToStr(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  const pad = s.length % 4 === 2 ? '==' : s.length % 4 === 3 ? '=' : '';
  const bin = atob(s + pad);
  let res = '';
  for (let i = 0; i < bin.length; i++) {
    res += String.fromCharCode(bin.charCodeAt(i));
  }
  return res;
}

export async function signHS256(secret, data) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(data));
  return b64urlEncode(sig);
}

export async function jwtSign(payload, secret, expSeconds) {
  const header = b64urlEncodeStr(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const exp = Math.floor(Date.now() / 1000) + expSeconds;
  const body = b64urlEncodeStr(JSON.stringify({ ...payload, exp }));
  const data = header + '.' + body;
  const sig = await signHS256(secret, data);
  return data + '.' + sig;
}

export async function jwtVerify(token, secret) {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const data = parts[0] + '.' + parts[1];
  const sig = parts[2];
  const expected = await signHS256(secret, data);
  if (sig !== expected) return null;
  const json = b64urlDecodeToStr(parts[1]);
  const payload = JSON.parse(json);
  if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
  return payload;
}

export async function hashPassword(password, salt) {
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', iterations: 100000, salt: new TextEncoder().encode(salt) }, keyMaterial, 256);
  return b64urlEncode(bits);
}

export function randomId() {
  return crypto.randomUUID();
}
